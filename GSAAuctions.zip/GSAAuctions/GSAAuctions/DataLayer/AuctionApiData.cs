﻿using GSAAuctions.Interface;
using GSAAuctions.Shared.Helper;
using GSAAuctions.Shared.Models;
using GSAAuctions.View;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace GSAAuctions.DataLayer
{
    public class AuctionApiData : IAuctionData
    {
        HttpClient client = null;
        RootObject model = null;
        private string AuctionUrl = "https://api.data.gov/gsa/auctions?api_key=**&format=JSON";
     

        public AuctionApiData()
        {
            client = new HttpClient();
        }

        public async Task<RootObject> GetAuctionData()
        {


            using (HttpResponseMessage response = await client.GetAsync(AuctionUrl))
            {

                var jsonString = response.Content.ReadAsStringAsync();
                jsonString.Wait();

                var settings = new JsonSerializerSettings();
                settings.ContractResolver = new CustomContractResolver();


                JsonSerializer ser = new JsonSerializer();
                var jObj = ser.Deserialize(new JReader(new StringReader(jsonString.Result))) as JObject;

                var newJson = jObj.ToString(Newtonsoft.Json.Formatting.None);


                model = Newtonsoft.Json.JsonConvert.DeserializeObject<RootObject>(newJson.ToLower());
                return model;
            }



        }




    }
}
