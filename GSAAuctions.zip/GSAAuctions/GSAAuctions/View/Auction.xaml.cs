﻿using GSAAuctions.ViewModel;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.Phone.UI.Input;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=234238

namespace GSAAuctions.View
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class Auction : Page
    {

        bool isHardwareButtonsAPIPresent = Windows.Foundation.Metadata.ApiInformation.IsTypePresent("Windows.Phone.UI.Input.HardwareButtons");
        public Auction()
        {
            this.InitializeComponent();
            this.NavigationCacheMode = NavigationCacheMode.Enabled;
            this.DataContext = App.MainViewModelLocator;

            if(isHardwareButtonsAPIPresent)
            HardwareButtons.BackPressed += HardwareButtons_BackPressed;
            this.Home.Click += this.Home_Click;
            this.BackButton.Click += this.Back_Click;
            this.InfoButton.Click += this.Info_Click;
            this.Refresh.Click += this.Refresh_Click;
        }

        private async void Info_Click(object sneder, RoutedEventArgs e)
        {

            string uriToLaunch = @"https://ranjanbiswas.wordpress.com/2015/10/10/privacy/";
            var uri = new Uri(uriToLaunch);
            var success = await Windows.System.Launcher.LaunchUriAsync(uri);

        }

        private async void Refresh_Click(object sneder, RoutedEventArgs e)
        {
            App.MainViewModelLocator.ErrorMessage = string.Empty;
            App.MainViewModelLocator.Counter = 0;
            App.MainViewModelLocator.GetAuctionList();
          //  ButtonTest();
        }

        private async void Home_Click(object sender, RoutedEventArgs e)
        {
            Frame.Navigate(typeof(MainPage));
        }

        private async void Back_Click(object sender, RoutedEventArgs e)
        {
            Frame frame = Window.Current.Content as Frame;
            if (frame == null)
            {
                return;
            }

            if (frame.CanGoBack)
            {
                frame.GoBack();
                // e.Handled = true;
            }
        }

        private void HardwareButtons_BackPressed(object sender, BackPressedEventArgs e)
        {
            Frame frame = Window.Current.Content as Frame;
            if (frame == null)
            {
                return;
            }

            if (frame.CanGoBack)
            {
                frame.GoBack();
                e.Handled = true;
            }
        }

        private void App_BackRequested(object sender,
    Windows.UI.Core.BackRequestedEventArgs e)
        {
            Frame rootFrame = Window.Current.Content as Frame;
            if (rootFrame == null)
                return;

            // Navigate back if possible, and if the event has not 
            // already been handled .
            if (rootFrame.CanGoBack && e.Handled == false)
            {
                e.Handled = true;
                rootFrame.GoBack();
            }
        }

        protected override void OnNavigatedTo(NavigationEventArgs e)
        {

     

        }

        private void ButtonTest()
        {
            if (App.MainViewModelLocator.TotalCount == 0)
            {
                btnNext.IsEnabled = false;
                btnPrevious.IsEnabled = false;

            }
            else
            {

                btnNext.IsEnabled = true;
                btnPrevious.IsEnabled = true;

                if (App.MainViewModelLocator.Counter > 0)
                {

                    btnPrevious.IsEnabled = true;
                }
                else
                {
                    btnPrevious.IsEnabled = false;
                }

                if (App.MainViewModelLocator.Counter < (App.MainViewModelLocator.TotalCount / 100))
                {

                    btnNext.IsEnabled = true;
                }
                else
                {
                    btnNext.IsEnabled = false;
                }

            }
        }

        private void btnSubmit_Click(object sender, RoutedEventArgs e)
        {
            string text = (sender as Button).Tag as string;
            App.MainViewModelLocator.AuctionDetail.Clear();
            App.MainViewModelLocator.Link = text;
            App.MainViewModelLocator.SetAuctionDetailItem(text);
            Frame.Navigate(typeof(AuctionDetail));
        }

        private void btnNext_Click(object sender, RoutedEventArgs e)
        {


            if (App.MainViewModelLocator.Counter <= (int) (App.MainViewModelLocator.TotalCount / 100))
            {
                App.MainViewModelLocator.ErrorMessage = string.Empty;
                App.MainViewModelLocator.Counter = App.MainViewModelLocator.Counter + 1;
                App.MainViewModelLocator.GetAuctionList();
               // ButtonTest();
            }
        }

        private void btnPrevious_Click(object sender, RoutedEventArgs e)
        {
            if (App.MainViewModelLocator.Counter >= 0)
            {
                App.MainViewModelLocator.ErrorMessage = string.Empty;
                App.MainViewModelLocator.Counter = App.MainViewModelLocator.Counter - 1;
                App.MainViewModelLocator.GetAuctionList();
               // ButtonTest();
                    }


        }
    }
}
