﻿using GSAAuctions.Interface;
using GSAAuctions.Manager.Concrete;
using GSAAuctions.Shared.Helper;
using GSAAuctions.Shared.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace GSAAuctions.ViewModel
{
    public class AuctionViewModel : INotifyPropertyChanged
    {
        private int counter;
        private int totalcount;
        private RootObject rootObject;
        private ObservableCollection<Result> auctionResults;
        private ObservableCollection<Result> auctionDetail;
        private string errorMessage;
        private string detailItemName;
        private bool isLoading;
        private AuctionManager auctionManager;
        private string link;
        public ICommand ButtonCommand { get; set; }

        private bool activateprevious;

            public bool ActivatePrevious
        {

            get { return activateprevious; }
            set
            {
                if (value == activateprevious) return;
                activateprevious = value;
                RaisePropertyChanged("ActivatePrevious");
            }

        }


        private bool activatenext;

            public bool ActivateNext
        {

            get { return activatenext; }
            set
            {
                if (value == activatenext) return;
                activatenext = value;
                RaisePropertyChanged("ActivateNext");
            }

        }


     

        public int Counter
        {

            get { return counter; }
            set
            {
                if (value == counter) return;
                counter = value;
                RaisePropertyChanged("Counter");
            }

        }

        public int TotalCount
        {

            get { return totalcount; }
            set
            {
                if (value == totalcount) return;
                totalcount = value;
                RaisePropertyChanged("TotalCount");
            }

        }

        public AuctionViewModel()
        {
           // ButtonCommand = new ActionCommand(GetAuctionList);
            rootObject = new RootObject();
            auctionDetail = new ObservableCollection<Result>();
            auctionResults = new ObservableCollection<Result>();
            auctionManager = new AuctionManager();
            counter = 0;
            totalcount = 0;
        }
        public string DetailItemName
        {
            get
            {
                return detailItemName;
            }
            set
            {
                if (value == detailItemName) return;
                detailItemName = value;
                RaisePropertyChanged("DetailItemName");
            }

        }

        public ObservableCollection<Result> AuctionDetail
        {
            get
            {
                return auctionDetail;
            }
            set
            {
                if (value == auctionDetail) return;
                auctionDetail = value;
                RaisePropertyChanged("AuctionDetail");
            }

        }

        public string Link
        {
            get
            {
                return link;
            }
            set
            {
                if (value == link) return;
                link = value;
                RaisePropertyChanged("Link");
            }

        }

        private string lotsInfoString;

        public string LotsInfoString
        {

            get { return lotsInfoString; }
            set
            {
                if (value == lotsInfoString) return;
                lotsInfoString = value;
                RaisePropertyChanged("LotsInfoString");
            }

        }


        public ObservableCollection<Result> AuctionResults
        {
            get
            {
                return auctionResults;
            }
            set
            {
                if (value == auctionResults) return;
                auctionResults = value;
                RaisePropertyChanged("AuctionResults");
            }

        }

        public void SetAuctionDetailItem(string item)
        {
            //ErrorMessage = string.Empty;
            lotsInfoString = string.Empty;
            ErrorMessageDetail = string.Empty;
            auctionDetail.Clear();
            AuctionDetail.Clear();

            if (AuctionResults.Count > 0)
            {
             

                foreach (Result detail in AuctionResults)
                {
                    if (detail.ItemDescURL.ToUpper() == item.ToUpper())
                    {
                        AuctionDetail.Add(detail);
                        DetailItemName = detail.ItemName.ToUpper();
                        foreach(LotInfo info in detail.LotInfo)
                        {

                            lotsInfoString = lotsInfoString + info.LotDescript + " ";
                        }

                        LotsInfoString = lotsInfoString;
                    }
                }

            }
            else
            {

                ErrorMessageDetail = "No Auction Details found";
            }
        }

        public async void GetAuctionList()
        {
            try
            {
                int lowerLevel = 0;
                int UpperLevel = 0;
                int totalcount = 0;


                lowerLevel = 100 * counter;
                UpperLevel = 100 * (counter + 1);

                AuctionResults.Clear();
                int count = 0;
                IsLoading = true;
                rootObject = await auctionManager.GetAucitonList();
                if (rootObject != null)
                {

                    totalcount = rootObject.Results.Count();

                    foreach (Result result in rootObject.Results)
                    {
                        if (count >= lowerLevel && count < UpperLevel)
                            AuctionResults.Add(result);

                        count = count + 1;
                    }

                    if (AuctionResults.Count > 0)
                    {
                        TotalCount = rootObject.Results.Count();
                        ButtonTest();
                        IsLoading = false;
                    }
                    else
                    {
                        ButtonTest();
                        IsLoading = false;
                    }

                  
                    ErrorMessage = "Displaying " + lowerLevel + " to " + UpperLevel + " results"; 
                }
            }
            catch { IsLoading = false; }
        }



        private void ButtonTest()
        {
            if (App.MainViewModelLocator.TotalCount == 0)
            {
                ActivateNext = false;
                ActivatePrevious = false;

            }
            else
            {

                ActivateNext = true;
                ActivatePrevious = true;

                if (App.MainViewModelLocator.Counter > 0)
                {

                    ActivatePrevious = true;
                }
                else
                {
                    ActivatePrevious = false;
                }

                if (App.MainViewModelLocator.Counter < (App.MainViewModelLocator.TotalCount / 100))
                {

                    ActivateNext = true;
                }
                else
                {
                    ActivateNext = false;
                }

            }
        }

        public bool IsLoading
        {
            get
            {
                return isLoading;
            }
            set
            {
                if (value == isLoading) return;
                isLoading = value;
                RaisePropertyChanged("IsLoading");
            }

        }

        public string ErrorMessage
        {
            get
            {
                return errorMessage;
            }
            set
            {
                if (value == errorMessage) return;
                errorMessage = value;
                RaisePropertyChanged("ErrorMessage");
            }

        }

        private string errorMessageDetail;
        public string ErrorMessageDetail
        {
            get
            {
                return errorMessageDetail;
            }
            set
            {
                if (value == errorMessageDetail) return;
                errorMessageDetail = value;
                RaisePropertyChanged("ErrorMessageDetail");
            }

        }

        public event PropertyChangedEventHandler PropertyChanged;

        private void RaisePropertyChanged(string propertyName)
        {
            if (this.PropertyChanged != null)
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }


    }
}