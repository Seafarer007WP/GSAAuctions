﻿using GSAAuctions.View;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace GSAAuctions
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();
            this.DataContext = App.MainViewModelLocator;
            App.MainViewModelLocator.AuctionDetail.Clear();
            
          
        }
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            App.MainViewModelLocator.AuctionDetail.Clear();
            App.MainViewModelLocator.GetAuctionList();
            AuctionInfo.Text = "GSA does not charge the general public to browse or to register at GSA Auctions; it is a U.S. Government website and is FREE to use! GSA Auctions utilizes Experian, a global consumer credit reporting agency, to facilitate user registration and the U.S. Department of Treasury's electronic payment service via gsaauctions.gov, to process payments. Users are required to confirm their identities during registration by providing a valid credit card. Your credit card account will be checked to make sure that it is valid and has the sufficient funds available to authorize a $1 charge. Within 24 hours, the authorization for $1 will expire. The user will notice a change in their available balance by $1 but the amount is never charged to their credit card account.";

        }

        private void AuctionButton_Click(object sender, RoutedEventArgs e)
        {
            App.MainViewModelLocator.AuctionDetail.Clear();
            Frame.Navigate(typeof(Auction));
        }
    }
}