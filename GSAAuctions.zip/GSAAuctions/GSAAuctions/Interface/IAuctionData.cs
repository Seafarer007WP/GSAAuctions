﻿using GSAAuctions.Shared.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GSAAuctions.Interface
{
    public interface IAuctionData
    {
        Task<RootObject> GetAuctionData();
    }
}
