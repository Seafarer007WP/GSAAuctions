﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GSAAuctions.Shared.Models;
using GSAAuctions.Interface;
using GSAAuctions.DataLayer;

namespace GSAAuctions.Manager.Concrete
{

 
    public class AuctionManager : IAuctionManager
    {
        private IAuctionData _service;
        public AuctionManager(IAuctionData service)
        {
            _service = service;
        }

        public AuctionManager()
        {
            _service = new AuctionApiData();
        }

        public async Task<RootObject> GetAucitonList()
        {

            RootObject obj = new RootObject();
            obj = await _service.GetAuctionData();
            return obj;

        }
    }
}
