﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GSAAuctions.Shared.Models
{
    public class RootObject : INotifyPropertyChanged
    {
        private List<Result> _results;
        public List<Result> Results
        {
            get
            {
                return _results;
            }
            set
            {
                _results = value;
                RaisePropertyChanged("Results");
            }
        }

public event PropertyChangedEventHandler PropertyChanged;

        private void RaisePropertyChanged(string propertyName)
        {
            if (this.PropertyChanged != null)
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
    public class LotInfo : INotifyPropertyChanged
    {
        public string LotSequence { get; set; }
        public string LotDescript { get; set; }

        public event PropertyChangedEventHandler PropertyChanged;

        private void RaisePropertyChanged(string propertyName)
        {
            if (this.PropertyChanged != null)
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
    
    public class Result : INotifyPropertyChanged
    {

        private string _saleno;

        [JsonProperty(PropertyName = "SaleNo")]
        public string SaleNo
        {
            get
            {
                return _saleno;
            }
            set
            {
                _saleno = value;
                RaisePropertyChanged("SaleNo");
            }
        }

        private string _lotno;

        public string LotNo
        {
            get
            {
                return _lotno;
            }
            set
            {
                _lotno = value;
                RaisePropertyChanged("LotNo");
            }
        }

        private string _aucstartdt;

        [JsonProperty(PropertyName = "AucStartDt")]
        public string AucStartDt
        {
            get
            {
                return _aucstartdt;
            }
            set
            {
                _aucstartdt = value;
                RaisePropertyChanged("AucStartDt");
            }
        }

        private string _aucenddt;

        public string AucEndDt
        {
            get
            {
                return _aucenddt;
            }
            set
            {
                _aucenddt = value;
                RaisePropertyChanged("AucEndDt");
            }
        }

        private string _itemname;
        public string ItemName
        {
            get
            {
                return _itemname.ToUpper();
            }
            set
            {
                _itemname = value;
                RaisePropertyChanged("ItemName");
            }
        }

        private string _propertyaddr1;
        public string PropertyAddr1
        {
            get
            {
                return _propertyaddr1;
            }
            set
            {
                _propertyaddr1 = value;
                RaisePropertyChanged("PropertyAddr1");
            }
        }

        private string _propertyaddr2;
        public string PropertyAddr2
        {
            get
            {
                return _propertyaddr2;
            }
            set
            {
                _propertyaddr2 = value;
                RaisePropertyChanged("PropertyAddr2");
            }
        }
        private string _propertyaddr3;
        public string PropertyAddr3
        {
            get
            {
                return _propertyaddr3;
            }
            set
            {
                _propertyaddr3 = value;
                RaisePropertyChanged("PropertyAddr3");
            }
        }




        private string _propercity;
        public string PropertyCity
        {
            get
            {
                return _propercity;
            }
            set
            {
                _propercity = value;
                RaisePropertyChanged("PropertyCity");
            }
        }

        private string _propertystate;
        public string PropertyState
        {
            get
            {
                return _propertystate;
            }
            set
            {
                _propertystate = value;
                RaisePropertyChanged("PropertyState");
            }
        }

        private string _propertyzip;
        public string PropertyZip
        {
            get
            {
                return _propertyzip;
            }
            set
            {
                _propertyzip = value;
                RaisePropertyChanged("PropertyZip");
            }
        }

        private string _auctionstatus;

        public string AuctionStatus
        {
            get
            {
                return _auctionstatus;
            }
            set
            {
                _auctionstatus = value;
                RaisePropertyChanged("AuctionStatus");
            }
        }
        private string _stringlocation;
        public string SaleLocation
        {
            get
            {
                return _stringlocation;
            }
            set
            {
                _stringlocation = value;
                RaisePropertyChanged("SaleLocation");
            }
        }

        private string _locationorg;
        public string LocationOrg
        {
            get
            {
                return _locationorg;
            }
            set
            {
                _locationorg = value;
                RaisePropertyChanged("LocationOrg");
            }
        }

        private string _locationstaddr;
        public string LocationStAddr
        {
            get
            {
                return _locationstaddr;
            }
            set
            {
                _locationstaddr = value;
                RaisePropertyChanged("LocationStAddr");
            }
        }

        private string _locationcity;
        public string LocationCity
        {
            get
            {
                return _locationcity;
            }
            set
            {
                _locationcity = value;
                RaisePropertyChanged("LocationCity");
            }
        }

        private string _locationst;
        public string LocationST
        {
            get
            {
                return _locationst;
            }
            set
            {
                _locationst = value;
                RaisePropertyChanged("LocationST");
            }
        }

        private string locationzip;
        public string LocationZip
        {
            get
            {
                return locationzip;
            }
            set
            {
                locationzip = value;
                RaisePropertyChanged("LocationZip");
            }
        }

        private string biddercount;
        public string BiddersCount
        {
            get
            {
                return biddercount;
            }
            set
            {
                biddercount = value;
                RaisePropertyChanged("BiddersCount");
            }
        }


        private List<LotInfo> _lostinfo;
        public List<LotInfo> LotInfo
        {
            get
            {
                return _lostinfo;
            }
            set
            {
                _lostinfo = value;
                RaisePropertyChanged("LotInfo");
            }
        }

        private string instruction1;
        public string Instruction1
        {
            get
            {
                return instruction1;
            }
            set
            {
                instruction1 = value;
                RaisePropertyChanged("Instruction1");
            }
        }
        private string instruction2;
        public string Instruction2
        {
            get
            {
                return instruction2;
            }
            set
            {
                instruction2 = value;
                RaisePropertyChanged("Instruction2");
            }
        }
        private string instruction3;
        public string Instruction3
        {
            get
            {
                return instruction3;
            }
            set
            {
                instruction3 = value;
                RaisePropertyChanged("Instruction3");
            }
        }





        private string _instruction;

        public string Instructions
        {
            get
            {
                return instruction1 + " " + instruction2 + " " + instruction3;
            }
            set
            {
                _instruction = value;
                RaisePropertyChanged("Instructions");
            }
        }

        private string contractofficer;
        public string ContractOfficer
        {
            get
            {
                return contractofficer;
            }
            set
            {
                contractofficer = value;
                RaisePropertyChanged("ContractOfficer");
            }
        }

        private string coemail;
        public string COEmail
        {
            get
            {
                return coemail;
            }
            set
            {
                coemail = value;
                RaisePropertyChanged("COEmail");
            }
        }
        public string COPhone { get; set; }
        public bool Reserve { get; set; }
        public double AucIncrement { get; set; }

        private string _highbidamount;
        public string HighBidAmount
        {
            get
            {
                return _highbidamount;
            }
            set
            {
                _highbidamount = "$" +  value;
                RaisePropertyChanged("HighBidAmount");
            }
        }

        
        public int InactivityTime { get; set; }

        private string _agencycode;
        public string AgencyCode
        {
            get
            {
                return _agencycode;
            }
            set
            {
                _agencycode = value;
                RaisePropertyChanged("AgencyCode");
            }
        }
        public string BureauCode { get; set; }

        private string _agencyname;
        public string AgencyName
        {
            get
            {
                return _agencyname;
            }
            set
            {
                _agencyname = value;
                RaisePropertyChanged("AgencyName");
            }
        }
        public string BureauName { get; set; }

        private string _itemdescurl;
        public string ItemDescURL
        {
            get
            {
                return _itemdescurl;
            }
            set
            {
                _itemdescurl = value;
                RaisePropertyChanged("ItemDescURL");
            }
        }

        private string _imageurl;
        public string ImageURL
        {
            get
            {
                return _imageurl;
            }
            set
            {
                _imageurl = value;
                RaisePropertyChanged("ImageURL");
            }
        }




        public event PropertyChangedEventHandler PropertyChanged;

        private void RaisePropertyChanged(string propertyName)
        {
            if (this.PropertyChanged != null)
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }




}
