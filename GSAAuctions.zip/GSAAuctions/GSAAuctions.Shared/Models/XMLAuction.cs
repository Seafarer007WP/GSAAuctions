﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GSAAuctions.Shared.Models
{

    /// <remarks/>
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "", IsNullable = false)]
    public partial class Response
    {

        private ResponseResults[] resultsField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("Results")]
        public ResponseResults[] Results
        {
            get
            {
                return this.resultsField;
            }
            set
            {
                this.resultsField = value;
            }
        }
    }

    /// <remarks/>
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
    public partial class ResponseResults
    {

        private string saleNoField;

        private ushort lotNoField;

        private System.DateTime aucStartDtField;

        private System.DateTime aucEndDtField;

        private string itemNameField;

        private string propertyAddr1Field;

        private string propertyAddr2Field;

        private string propertyAddr3Field;

        private string propertyCityField;

        private string propertyStateField;

        private uint propertyZipField;

        private string auctionStatusField;

        private string saleLocationField;

        private string locationOrgField;

        private string locationStAddrField;

        private string locationCityField;

        private string locationSTField;

        private uint locationZipField;

        private byte biddersCountField;

        private ResponseResultsLotInfo lotInfoField;

        private string instruction1Field;

        private string instruction2Field;

        private string instruction3Field;

        private string contractOfficerField;

        private string cOEmailField;

        private ulong cOPhoneField;

        private bool reserveField;

        private decimal aucIncrementField;

        private decimal highBidAmountField;

        private byte inactivityTimeField;

        private object agencyCodeField;

        private object bureauCodeField;

        private string agencyNameField;

        private string bureauNameField;

        private string itemDescURLField;

        private string imageURLField;

        /// <remarks/>
        public string SaleNo
        {
            get
            {
                return this.saleNoField;
            }
            set
            {
                this.saleNoField = value;
            }
        }

        /// <remarks/>
        public ushort LotNo
        {
            get
            {
                return this.lotNoField;
            }
            set
            {
                this.lotNoField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(DataType = "date")]
        public System.DateTime AucStartDt
        {
            get
            {
                return this.aucStartDtField;
            }
            set
            {
                this.aucStartDtField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(DataType = "date")]
        public System.DateTime AucEndDt
        {
            get
            {
                return this.aucEndDtField;
            }
            set
            {
                this.aucEndDtField = value;
            }
        }

        /// <remarks/>
        public string ItemName
        {
            get
            {
                return this.itemNameField;
            }
            set
            {
                this.itemNameField = value;
            }
        }

        /// <remarks/>
        public string PropertyAddr1
        {
            get
            {
                return this.propertyAddr1Field;
            }
            set
            {
                this.propertyAddr1Field = value;
            }
        }

        /// <remarks/>
        public string PropertyAddr2
        {
            get
            {
                return this.propertyAddr2Field;
            }
            set
            {
                this.propertyAddr2Field = value;
            }
        }

        /// <remarks/>
        public string PropertyAddr3
        {
            get
            {
                return this.propertyAddr3Field;
            }
            set
            {
                this.propertyAddr3Field = value;
            }
        }

        /// <remarks/>
        public string PropertyCity
        {
            get
            {
                return this.propertyCityField;
            }
            set
            {
                this.propertyCityField = value;
            }
        }

        /// <remarks/>
        public string PropertyState
        {
            get
            {
                return this.propertyStateField;
            }
            set
            {
                this.propertyStateField = value;
            }
        }

        /// <remarks/>
        public uint PropertyZip
        {
            get
            {
                return this.propertyZipField;
            }
            set
            {
                this.propertyZipField = value;
            }
        }

        /// <remarks/>
        public string AuctionStatus
        {
            get
            {
                return this.auctionStatusField;
            }
            set
            {
                this.auctionStatusField = value;
            }
        }

        /// <remarks/>
        public string SaleLocation
        {
            get
            {
                return this.saleLocationField;
            }
            set
            {
                this.saleLocationField = value;
            }
        }

        /// <remarks/>
        public string LocationOrg
        {
            get
            {
                return this.locationOrgField;
            }
            set
            {
                this.locationOrgField = value;
            }
        }

        /// <remarks/>
        public string LocationStAddr
        {
            get
            {
                return this.locationStAddrField;
            }
            set
            {
                this.locationStAddrField = value;
            }
        }

        /// <remarks/>
        public string LocationCity
        {
            get
            {
                return this.locationCityField;
            }
            set
            {
                this.locationCityField = value;
            }
        }

        /// <remarks/>
        public string LocationST
        {
            get
            {
                return this.locationSTField;
            }
            set
            {
                this.locationSTField = value;
            }
        }

        /// <remarks/>
        public uint LocationZip
        {
            get
            {
                return this.locationZipField;
            }
            set
            {
                this.locationZipField = value;
            }
        }

        /// <remarks/>
        public byte BiddersCount
        {
            get
            {
                return this.biddersCountField;
            }
            set
            {
                this.biddersCountField = value;
            }
        }

        /// <remarks/>
        public ResponseResultsLotInfo LotInfo
        {
            get
            {
                return this.lotInfoField;
            }
            set
            {
                this.lotInfoField = value;
            }
        }

        /// <remarks/>
        public string Instruction1
        {
            get
            {
                return this.instruction1Field;
            }
            set
            {
                this.instruction1Field = value;
            }
        }

        /// <remarks/>
        public string Instruction2
        {
            get
            {
                return this.instruction2Field;
            }
            set
            {
                this.instruction2Field = value;
            }
        }

        /// <remarks/>
        public string Instruction3
        {
            get
            {
                return this.instruction3Field;
            }
            set
            {
                this.instruction3Field = value;
            }
        }

        /// <remarks/>
        public string ContractOfficer
        {
            get
            {
                return this.contractOfficerField;
            }
            set
            {
                this.contractOfficerField = value;
            }
        }

        /// <remarks/>
        public string COEmail
        {
            get
            {
                return this.cOEmailField;
            }
            set
            {
                this.cOEmailField = value;
            }
        }

        /// <remarks/>
        public ulong COPhone
        {
            get
            {
                return this.cOPhoneField;
            }
            set
            {
                this.cOPhoneField = value;
            }
        }

        /// <remarks/>
        public bool Reserve
        {
            get
            {
                return this.reserveField;
            }
            set
            {
                this.reserveField = value;
            }
        }

        /// <remarks/>
        public decimal AucIncrement
        {
            get
            {
                return this.aucIncrementField;
            }
            set
            {
                this.aucIncrementField = value;
            }
        }

        /// <remarks/>
        public decimal HighBidAmount
        {
            get
            {
                return this.highBidAmountField;
            }
            set
            {
                this.highBidAmountField = value;
            }
        }

        /// <remarks/>
        public byte InactivityTime
        {
            get
            {
                return this.inactivityTimeField;
            }
            set
            {
                this.inactivityTimeField = value;
            }
        }

        /// <remarks/>
        public object AgencyCode
        {
            get
            {
                return this.agencyCodeField;
            }
            set
            {
                this.agencyCodeField = value;
            }
        }

        /// <remarks/>
        public object BureauCode
        {
            get
            {
                return this.bureauCodeField;
            }
            set
            {
                this.bureauCodeField = value;
            }
        }

        /// <remarks/>
        public string AgencyName
        {
            get
            {
                return this.agencyNameField;
            }
            set
            {
                this.agencyNameField = value;
            }
        }

        /// <remarks/>
        public string BureauName
        {
            get
            {
                return this.bureauNameField;
            }
            set
            {
                this.bureauNameField = value;
            }
        }

        /// <remarks/>
        public string ItemDescURL
        {
            get
            {
                return this.itemDescURLField;
            }
            set
            {
                this.itemDescURLField = value;
            }
        }

        /// <remarks/>
        public string ImageURL
        {
            get
            {
                return this.imageURLField;
            }
            set
            {
                this.imageURLField = value;
            }
        }
    }

    /// <remarks/>
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
    public partial class ResponseResultsLotInfo
    {

        private object[] itemsField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("LotDescript", typeof(string))]
        [System.Xml.Serialization.XmlElementAttribute("LotSequence", typeof(byte))]
        public object[] Items
        {
            get
            {
                return this.itemsField;
            }
            set
            {
                this.itemsField = value;
            }
        }
    }


}
