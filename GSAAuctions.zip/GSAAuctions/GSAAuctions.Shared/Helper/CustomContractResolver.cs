﻿using GSAAuctions.Shared.Models;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json.Serialization;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace GSAAuctions.Shared.Helper
{
    public class CustomContractResolver : DefaultContractResolver
    {
        private readonly char _delimiter;

        public CustomContractResolver()
       
    {
            
        }

        protected override string ResolvePropertyName(string propertyName)
        {
            return propertyName.ToString().ToUpper();
        }
    }
}
